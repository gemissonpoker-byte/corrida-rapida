package com.example.corridarapida

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }

        fun campo(rotulo: String, chave: String, padrao: Float): EditText {
            col.addView(TextView(this).apply { text = rotulo })
            return EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setText(sp.getFloat(chave, padrao).toString())
                col.addView(this)
            }
        }
        val km = campo("Mínimo R$/km", "minKm", 1.8f)
        val h = campo("Mínimo R$/hora", "minH", 35f)

        col.addView(Button(this).apply {
            text = "Salvar metas"
            setOnClickListener {
                sp.edit()
                    .putFloat("minKm", km.text.toString().replace(",", ".").toFloatOrNull() ?: 1.8f)
                    .putFloat("minH", h.text.toString().replace(",", ".").toFloatOrNull() ?: 35f)
                    .apply()
                Toast.makeText(this@MainActivity, "Salvo", Toast.LENGTH_SHORT).show()
            }
        })
        col.addView(TextView(this).apply {
            text = "\nAtive o serviço \"Corrida Rápida\" em Acessibilidade. Depois é só abrir o app do Uber Driver."
        })
        col.addView(Button(this).apply {
            text = "Abrir Acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(col)
    }
}

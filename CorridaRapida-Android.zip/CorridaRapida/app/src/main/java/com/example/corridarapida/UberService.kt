package com.example.corridarapida

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

class UberService : AccessibilityService() {

    // AJUSTE AQUI se o texto do app mudar. Formato esperado na tela:
    //   "R$ 18,50"  ...  "4 min (1,2 km) de distância"  ...  "Viagem de 15 min (5,3 km)"
    private val precoRx = Regex("R\\$\\s*(\\d+(?:[.,]\\d{1,2})?)")
    private val trechoRx = Regex("(\\d+)\\s*min\\s*\\(([\\d.,]+)\\s*km\\)")
    private val pacotesAlvo = setOf("com.ubercab.driver")

    private var overlay: TextView? = null

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg !in pacotesAlvo) {
            // Só esconde se o app em primeiro plano for outro app de verdade (não o nosso overlay)
            if (pkg != packageName) esconder()
            return
        }
        val root = rootInActiveWindow ?: return
        val sb = StringBuilder()
        coletar(root, sb)
        analisar(sb.toString())
    }

    private fun coletar(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null) return
        n.text?.let { sb.append(it).append('\n') }
        n.contentDescription?.let { sb.append(it).append('\n') }
        for (i in 0 until n.childCount) coletar(n.getChild(i), sb)
    }

    private fun num(s: String): Double =
        (if (s.contains(",")) s.replace(".", "").replace(",", ".") else s).toDoubleOrNull() ?: 0.0

    private fun analisar(txt: String) {
        val preco = precoRx.find(txt)?.groupValues?.get(1)?.let(::num)
        val trechos = trechoRx.findAll(txt).take(2).toList()
        if (preco == null || preco <= 0 || trechos.size < 2) { esconder(); return }

        val min = trechos.sumOf { it.groupValues[1].toDouble() }
        val km = trechos.sumOf { num(it.groupValues[2]) }
        if (min <= 0 || km <= 0) { esconder(); return }

        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        val metaKm = sp.getFloat("minKm", 1.8f)
        val metaH = sp.getFloat("minH", 35f)

        val rkm = preco / km
        val rh = preco / (min / 60.0)
        val okKm = rkm >= metaKm
        val okH = rh >= metaH

        val (titulo, cor) = when {
            okKm && okH -> "✅ ACEITA" to Color.rgb(18, 161, 80)
            okKm || okH -> "⚠️ LIMITE" to Color.rgb(224, 154, 0)
            else -> "❌ RECUSA" to Color.rgb(211, 47, 47)
        }
        mostrar("$titulo\nR$%.2f/km · R$%.0f/h".format(rkm, rh), cor)
    }

    private fun mostrar(texto: String, cor: Int) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = overlay ?: TextView(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(40, 24, 40, 24)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 180 }
            wm.addView(this, lp)
            overlay = this
        }
        v.text = texto
        v.setBackgroundColor(cor)
    }

    private fun esconder() {
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
            overlay = null
        }
    }

    override fun onInterrupt() { esconder() }
    override fun onDestroy() { esconder(); super.onDestroy() }
}
